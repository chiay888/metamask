# This folder is for images you include in FAQ topics.
